<aside class="main-sidebar sidebar-dark-primary elevation-4" style="min-height: 917px;">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
        <img src="<?php echo e(asset('img/logo-white.svg')); ?>" alt="<?php echo e(trans('global.site_title')); ?>" />
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?php echo e(route("admin.home")); ?>" class="nav-link">
                        <p>
                            <i class="fas fa-tachometer-alt">

                            </i>
                            <span><?php echo e(trans('global.dashboard')); ?></span>
                        </p>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is('admin/permissions*') ? 'menu-open' : ''); ?> <?php echo e(request()->is('admin/roles*') ? 'menu-open' : ''); ?> <?php echo e(request()->is('admin/users*') ? 'menu-open' : ''); ?>">
                        <a class="nav-link nav-dropdown-toggle">
                            <i class="fas fa-users">

                            </i>
                            <p>
                                <span><?php echo e(trans('global.userManagement.title')); ?></span>
                                <i class="right fa fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.permissions.index")); ?>" class="nav-link <?php echo e(request()->is('admin/permissions') || request()->is('admin/permissions/*') ? 'active' : ''); ?>">
                                        <i class="fas fa-unlock-alt">

                                        </i>
                                        <p>
                                            <span><?php echo e(trans('global.permission.title')); ?></span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.roles.index")); ?>" class="nav-link <?php echo e(request()->is('admin/roles') || request()->is('admin/roles/*') ? 'active' : ''); ?>">
                                        <i class="fas fa-briefcase">

                                        </i>
                                        <p>
                                            <span><?php echo e(trans('global.role.title')); ?></span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.users.index")); ?>" class="nav-link <?php echo e(request()->is('admin/users') || request()->is('admin/users/*') ? 'active' : ''); ?>">
                                        <i class="fas fa-user">

                                        </i>
                                        <p>
                                            <span><?php echo e(trans('global.user.title')); ?></span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                

                <li class="nav-item">
                    <a href="<?php echo e(route("admin.customer.index")); ?>" class="nav-link <?php echo e(request()->is('admin/customer') || request()->is('admin/customer/*') ? 'active' : ''); ?>">
                    <i class="fa fa-users" aria-hidden="true">

                    </i>
                    <p>
                        <span><?php echo e(trans('Customers')); ?></span>
                    </p>

                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route("admin.notification.index")); ?>" class="nav-link">
                        <i class="fas fa-bell" aria-hidden="true">

                        </i>
                        <p>
                            <span><?php echo e(trans('Notifications')); ?></span>
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route("admin.contact.index")); ?>" class="nav-link">
                        <i class="fas fa-address-book" aria-hidden="true">

                        </i>
                        <p>
                            <span><?php echo e(trans('Contacts')); ?></span>
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route("admin.loan.index")); ?>" class="nav-link">
                        <i class="fa fa-address-card" aria-hidden="true">

                        </i>
                        <p>
                            <span><?php echo e(trans('Apply_loans')); ?></span>
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route("admin.referral.index")); ?>" class="nav-link">
                         <i class="fas fa-sync" aria-hidden="true">

                         </i>
                         <p>
                            <span><?php echo e(trans('Referrals')); ?></span>
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route("admin.setting.index")); ?>" class="nav-link">
                         <i class="fas fa-cogs" aria-hidden="true">

                         </i>
                         <p>
                            <span><?php echo e(trans('Settings')); ?></span>
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                            <i class="fas fa-sign-out-alt">

                            </i>
                            <p>
                                <span><?php echo e(trans('global.logout')); ?></span>
                            </p>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH F:\xampp\htdocs\loanzspot\resources\views/partials/menu.blade.php ENDPATH**/ ?>